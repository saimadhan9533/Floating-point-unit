Floating point unit: it is similar to alu but in flu we will normalized numbers instead of direct numbers .for normalized numbers we need sign which is of 1-bit,where 0 represents positive and 1 represents negative.
then mantissa which of 23-bit size number.and final part is exponential which is of 8-bit. all this for single precision bit. in floating point unit there is single and double precision bit.where single is of 32-bit 
double is of 64-bit.which will perform operations similar to alu such as addition ,subraction,multiplication,division in addition with square root.there are few operations which are not performed in the code such as
rounding off,overflow and underflow etc.,
